// Проверка без браузера: node tools/check.js (из корня проекта)
const fs=require('fs'),vm=require('vm'),A='app/src/main/assets/',bad=[],els={},store={};
const ok=(c,m)=>{if(!c)bad.push(m)};
function mk(){const S={clientWidth:400,clientHeight:800};
 return new Proxy(()=>0,{get(t,k){if(k===Symbol.toPrimitive)return()=>1;if(typeof k==='symbol')return undefined;if(!(k in S))S[k]=mk();return S[k]},
  set(t,k,v){S[k]=v;return true},apply(){return mk()}})}
const ctx={innerWidth:400,innerHeight:800,devicePixelRatio:2,alert(){},requestAnimationFrame(){},
 localStorage:{getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=v}},
 document:{getElementById:i=>els[i]||(els[i]=mk()),createElement:()=>mk(),body:mk()}};
ctx.window=ctx;vm.createContext(ctx);
const js=/<script>([\s\S]*?)<\/script>/.exec(fs.readFileSync(A+'index.html','utf8'))[1];
try{vm.runInContext(fs.readFileSync(A+'data.js','utf8'),ctx);new vm.Script(js);vm.runInContext(js,ctx)}catch(e){bad.push('Исключение при запуске: '+e.stack)}
const {LAND,SEAS,EP,EV,HG:H}=ctx;
if(EP&&H){
 [...LAND,...SEAS,...EP.flatMap(e=>e[3].map(t=>t[1]))].forEach((p,i)=>{ok(p.length>=6&&p.length%2==0,'полигон '+i+': неверная длина');
  for(let j=0;j<p.length;j+=2)ok(Math.abs(p[j])<=180&&Math.abs(p[j+1])<=90,'полигон '+i+': координаты вне диапазона')});
 ok(EP[0][0]===862,'эпохи должны начинаться с 862');ok(EP[EP.length-1][1]>2025,'последняя эпоха должна покрывать 2025');
 EP.forEach((e,i)=>{ok(e[0]<e[1],'эпоха '+i+': от>=до');if(i)ok(EP[i-1][1]===e[0],'разрыв между эпохами '+(i-1)+' и '+i);
  e[3].forEach(t=>ok(/^#[0-9a-f]{6}$/i.test(t[0]),'цвет '+t[0]))});
 EV.forEach(e=>ok(e[0]>=862&&e[0]<=2025&&Math.abs(e[1])<=90&&Math.abs(e[2])<=180&&e[3]&&e[4],'событие: '+e[3]));
 let n=0;const deg=180/Math.PI;
 for(const[a,b,z]of[[.9,.7,1.1],[0,0,1.5],[-.5,2.5,3],[1.2,-2,.8]]){H.set(a,b,z);const m=H.M(),c=H.unpr(200,400);
  ok(c&&Math.abs(c[0]-a*deg)<1e-6&&Math.abs(c[1]-b*deg)<1e-6,'центр экрана ≠ центру вида');
  for(const[la,lo]of[[a*deg,b*deg],[a*deg+8,b*deg-12],[a*deg-6,b*deg+9]]){const p=H.pr(la,lo,m);if(!p.v)continue;const u=H.unpr(p.x,p.y);n++;
   ok(u&&Math.abs(u[0]-la)<.01&&Math.abs((u[1]-lo+540)%360-180)<.01,'проекция↔обратная: '+la+','+lo+' → '+u)}}
 ok(n>=8,'мало точек для проверки проекции: '+n);
 try{for(let y=862;y<=2025;y+=9)H.setYear(y);H.draw();
  els.add.onclick();els.ey.value=5;els.sv.onclick();ok(String(els.em.textContent).includes('Год'),'нет ошибки для неверного года');
  els.ey.value=1900;els.et.value='Тест';els.ed2.value='описание';els.ela.value='55.5';els.elo.value='37.6';els.sv.onclick();
  ok(store.hg&&JSON.parse(store.hg).length===1,'своя дата не сохранилась');ok(els.ed.hidden===true,'редактор не закрылся');
 }catch(e){bad.push('Исключение в сценарии: '+e.stack)}
}
console.log(bad.length?'ОШИБКИ:\n'+bad.join('\n'):'ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ');process.exit(bad.length?1:0);
