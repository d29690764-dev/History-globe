var GEO=null; // заменяется при сборке скриптом tools/fetch_geo.py
