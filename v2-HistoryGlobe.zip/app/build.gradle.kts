plugins { id("com.android.application") }

android {
    namespace = "ru.ege.historyglobe"
    compileSdk = 34
    defaultConfig {
        applicationId = "ru.ege.historyglobe"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

// Перед сборкой скачиваем реальные геоданные Natural Earth (реки, города, берега).
// Нет сети или сбой — сборка продолжается со встроенной картой.
val fetchGeo by tasks.registering(Exec::class) {
    workingDir = rootDir
    commandLine("sh", "-c", "python3 tools/fetch_geo.py || echo 'geo: пропущено'")
}
tasks.matching { it.name == "preBuild" || (it.name.startsWith("merge") && it.name.endsWith("Assets")) }
    .configureEach { dependsOn(fetchGeo) }
