// Проверка без браузера: node tools/check.js (из корня проекта)
const fs=require('fs'),vm=require('vm'),A='app/src/main/assets/',bad=[];
const ok=(c,m)=>{if(!c)bad.push(m)};
const src=n=>fs.readFileSync(A+n,'utf8'),js=/<script>([\s\S]*?)<\/script>/.exec(src('index.html'))[1];
function mk(){const S={clientWidth:400,clientHeight:800,getBoundingClientRect:()=>({left:0,top:0}),measureText:()=>({width:50})};
 return new Proxy(()=>0,{get(t,k){if(k===Symbol.toPrimitive)return()=>1;if(typeof k==='symbol')return undefined;if(!(k in S))S[k]=mk();return S[k]},set(t,k,v){S[k]=v;return true},apply(){return mk()}})}
function boot(geo,tag){const els={},store={};
 const ctx={innerWidth:400,innerHeight:800,devicePixelRatio:2,navigator:{deviceMemory:8},alert(){},requestAnimationFrame(){},
  localStorage:{getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=v}},
  document:{getElementById:i=>els[i]||(els[i]=mk()),createElement:()=>mk(),body:mk()}};
 ctx.window=ctx;vm.createContext(ctx);
 try{vm.runInContext(src('data.js'),ctx);if(geo)ctx.GEO=geo;else vm.runInContext(src('geo.js'),ctx);new vm.Script(js);vm.runInContext(js,ctx)}
 catch(e){bad.push(tag+': исключение при запуске: '+e.stack);return null}
 return{ctx,els,store,H:ctx.HG,tag}}
const FAKE={land:[[[-10,35,40,35,40,60,-10,60]]],lakes:[],rivers:[[3,'Тест',[30,50,31,51,32,52,33,53,34,54,35,55,36,56,37,57,38,58]]],
 places:[[37.6,55.7,'Москва',1.7,1],[30.3,59.9,'Санкт-Петербург',1.7,1],[39.7,54.6,'Рязань',3,0]]};
const runs=[boot(null,'без GEO'),boot(FAKE,'с GEO')];
const C=runs[0]&&runs[0].ctx;
if(C){const {LAND,SEAS,EP,EV,HC,RIV,TS}=C;
 [...LAND,...SEAS,...Object.values(TS).flatMap(s=>s.map(t=>t[1]))].forEach((p,i)=>{ok(p.length>=6&&p.length%2==0,'полигон '+i+': неверная длина');
  for(let j=0;j<p.length;j+=2)ok(Math.abs(p[j])<=180&&Math.abs(p[j+1])<=90,'полигон '+i+': координаты вне диапазона')});
 ok(EP[0][0]===862,'эпохи должны начинаться с 862');ok(EP[EP.length-1][1]>2025,'последняя эпоха должна покрывать 2025');
 EP.forEach((e,i)=>{ok(e[0]<e[1],'эпоха '+i+': от>=до');if(i)ok(EP[i-1][1]===e[0],'разрыв между эпохами '+(i-1)+' и '+i);
  ok(Array.isArray(e[3])&&e[3].length>0,'эпоха '+i+': нет территорий');e[3].forEach(t=>ok(/^#[0-9a-f]{6}$/i.test(t[0]),'цвет '+t[0]))});
 EV.forEach(e=>ok(e[0]>=862&&e[0]<=2025&&Math.abs(e[1])<=90&&Math.abs(e[2])<=180&&e[3]&&e[4],'событие: '+e[3]));
 HC.forEach(c=>ok(c[0]&&Math.abs(c[1])<=90&&Math.abs(c[2])<=180&&c[3]>=800&&c[3]<=2025&&(c[4]==1||c[4]==2),'город: '+c[0]));
 RIV.forEach(r=>ok(r[1]&&r[2].length%2==0&&r[2].length>=4,'река: '+r[1]));
 console.log('данные: эпох',EP.length,', событий',EV.length,', городов',HC.length,', рек (запасных)',RIV.length)}
const deg=180/Math.PI;
for(const R of runs){if(!R)continue;const {H,els,store,tag}=R;
 try{let n=0;
  for(const[a,b,z]of[[.9,.7,1.1],[0,0,1.5],[-.5,2.5,3],[1.2,-2,.8],[.97,.65,6]]){H.set(a,b,z);const m=H.M(),c=H.unpr(200,400);
   ok(c&&Math.abs(c[0]-a*deg)<1e-6&&Math.abs(c[1]-b*deg)<1e-6,tag+': центр экрана ≠ центру вида');
   for(const[la,lo]of[[a*deg,b*deg],[a*deg+8,b*deg-12],[a*deg-6,b*deg+9]]){const p=H.pr(la,lo,m);if(!p.v)continue;const u=H.unpr(p.x,p.y);n++;
    ok(u&&Math.abs(u[0]-la)<.01&&Math.abs((u[1]-lo+540)%360-180)<.01,tag+': проекция↔обратная '+la+','+lo+' → '+u)}}
  ok(n>=10,tag+': мало точек для проверки проекции: '+n);
  for(let y=862;y<=2025;y+=7)H.setYear(y);
  for(const[a,b,z]of[[.87,.65,1.1],[.97,.65,5],[.97,.65,10],[1,.6,2.2]]){H.set(a,b,z);H.setYear(1700);H.draw();H.setYear(1941);H.draw()}
  els.add.onclick();els.ey.value=5;els.sv.onclick();ok(String(els.em.textContent).includes('Год'),tag+': нет ошибки для неверного года');
  els.ey.value=1900;els.et.value='Тест';els.ed2.value='описание';els.ela.value='55.5';els.elo.value='37.6';els.sv.onclick();
  ok(store.hg&&JSON.parse(store.hg).length===1,tag+': своя дата не сохранилась');ok(els.ed.hidden===true,tag+': редактор не закрылся');
  H.setYear(1812);const y0=H.get().year,p0=H.get().ppy;
  els.tl.onpointerdown({pointerId:1,clientX:200,clientY:30});els.tl.onpointermove({pointerId:1,clientX:150,clientY:30});els.tl.onpointerup({pointerId:1,clientX:150,clientY:30});
  ok(H.get().year>y0,tag+': лента не прокрутилась');
  els.zi.onclick();ok(H.get().ppy>p0,tag+': масштаб ленты не вырос');
  H.setYear(1812);els.tl.onpointerdown({pointerId:2,clientX:200,clientY:63});els.tl.onpointerup({pointerId:2,clientX:200,clientY:63});
  ok(H.get().year===1812,tag+': тап по событию сместил год');ok(els.card.hidden===false,tag+': карточка события не открылась');
 }catch(e){bad.push(tag+': '+e.stack)}}
console.log(bad.length?'ОШИБКИ:\n'+bad.join('\n'):'ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ');process.exit(bad.length?1:0);
