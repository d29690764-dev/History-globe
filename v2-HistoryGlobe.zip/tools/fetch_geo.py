#!/usr/bin/env python3
"""Скачивает открытые данные Natural Earth и пишет app/src/main/assets/geo.js:
берега, озёра, реки и ~7000 населённых пунктов (с русскими названиями, если они есть в данных).
Вызывается из Gradle перед сборкой. При любой ошибке прежний geo.js остаётся нетронутым."""
import json, math, os, sys, urllib.request

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'app', 'src', 'main', 'assets', 'geo.js')
BASES = ['https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/',
         'https://cdn.jsdelivr.net/gh/nvkelso/natural-earth-vector@master/geojson/']


def get(name):
    for b in BASES:
        try:
            with urllib.request.urlopen(b + name, timeout=180) as r:
                return json.loads(r.read().decode('utf-8'))
        except Exception as e:
            print('  нет', b + name, '->', e)
    return None


def dp(pts, eps):  # Дуглас–Пекер без рекурсии
    n = len(pts)
    if n < 3:
        return pts
    keep = [False] * n
    keep[0] = keep[-1] = True
    st = [(0, n - 1)]
    while st:
        a, b = st.pop()
        ax, ay = pts[a][0], pts[a][1]
        dx, dy = pts[b][0] - ax, pts[b][1] - ay
        L = dx * dx + dy * dy
        mi, md = -1, 0.0
        for i in range(a + 1, b):
            qx, qy = pts[i][0] - ax, pts[i][1] - ay
            t = 0 if L == 0 else max(0, min(1, (qx * dx + qy * dy) / L))
            d = math.hypot(qx - t * dx, qy - t * dy)
            if d > md:
                mi, md = i, d
        if md > eps:
            keep[mi] = True
            st += [(a, mi), (mi, b)]
    return [p for p, k in zip(pts, keep) if k]


def flat(pts):
    return [round(c, 2) for p in pts for c in p[:2]]


def parts(g, kinds):
    if not g:
        return []
    t, c = g.get('type'), g.get('coordinates')
    if t == kinds[0]:
        return [c]
    return c if t == kinds[1] else []


def props(f):
    return {k.lower(): v for k, v in (f.get('properties') or {}).items()}


def num(v, default):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else default


def area_polys(fc, eps):
    out = []
    for f in (fc or {}).get('features', []):
        for poly in parts(f.get('geometry'), ('Polygon', 'MultiPolygon')):
            rings = [flat(dp(r, eps)) for r in poly]
            rings = [r for r in rings if len(r) >= 6]
            if rings:
                out.append(rings)
    return out


def river_lines(fc, eps):
    out = []
    for f in (fc or {}).get('features', []):
        p = props(f)
        k = int(num(p.get('scalerank'), 8))
        name = p.get('name_ru') or p.get('name') or ''
        for ln in parts(f.get('geometry'), ('LineString', 'MultiLineString')):
            pts = flat(dp(ln, eps))
            if len(pts) >= 4:
                out.append([k, name, pts])
    return out


def place_list(fc):
    out = []
    for f in (fc or {}).get('features', []):
        g = f.get('geometry') or {}
        if g.get('type') != 'Point':
            continue
        p = props(f)
        name = p.get('name_ru') or p.get('name') or p.get('nameascii')
        if not name:
            continue
        mz = num(p.get('min_zoom'), 2 + 0.6 * num(p.get('scalerank'), 8))
        cap = 1 if (p.get('adm0cap') == 1 or 'capital' in str(p.get('featurecla', '')).lower()) else 0
        out.append([round(g['coordinates'][0], 2), round(g['coordinates'][1], 2), name, round(float(mz), 1), cap])
    out.sort(key=lambda r: r[3])
    return out


def build(land, lakes, rivers, places):
    return {'land': area_polys(land, 0.03), 'lakes': area_polys(lakes, 0.03),
            'rivers': river_lines(rivers, 0.02), 'places': place_list(places)}


def write_js(geo, path):
    with open(path, 'w', encoding='utf-8') as f:
        f.write('var GEO=' + json.dumps(geo, ensure_ascii=False, separators=(',', ':')) + ';\n')


def main():
    print('Natural Earth -> geo.js')
    land = get('ne_50m_land.geojson')
    lakes = get('ne_50m_lakes.geojson')
    rivers = get('ne_10m_rivers_lake_centerlines.geojson')
    places = get('ne_10m_populated_places.geojson') or get('ne_10m_populated_places_simple.geojson')
    geo = build(land, lakes, rivers, places)
    print('  суша %d, озёра %d, реки %d, населённых пунктов %d' %
          tuple(len(geo[k]) for k in ('land', 'lakes', 'rivers', 'places')))
    if not geo['land']:
        print('  суша не получена - остаётся встроенная карта')
        return
    write_js(geo, OUT)
    print('  записано', os.path.getsize(OUT) // 1024, 'КБ')


if __name__ == '__main__':
    main()
